export default function() {
  this.transition(
    this.use('crossFade')
  );
}
